package com.geofinder.geofinder;

public class Starter {
    public static void main(String[] args) {
        Main.main(args);
    }
}