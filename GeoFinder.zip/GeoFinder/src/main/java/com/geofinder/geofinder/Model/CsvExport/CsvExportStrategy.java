package com.geofinder.geofinder.Model.CsvExport;

public interface CsvExportStrategy {
    void exportToCsv();
}
